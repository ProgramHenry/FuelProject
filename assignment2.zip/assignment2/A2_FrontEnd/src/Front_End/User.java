/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Front_End;

/**
 *
 * @author jonat
 */
class User {
    private int Form,Gallons,SPrice, Total;
    private String Username,Address;
    
    public User(int Form, int Gallons, int SPrice, int Total, String Username, String Address){
        this.Form=Form;
        this.Gallons = Gallons;
        this.SPrice = SPrice;
        this.Total = Total;
        this.Username = Username;
        this.Address = Address;
    }
    
    public int getForm(){
        return Form;
    }
    public int getGallons(){
        return Gallons;
    }
    public int getSPrice(){
        return SPrice;
    }
    public int getTotal(){
        return Total;
    }
    public String getUser(){
        return Username;
    }
    public String getAdd(){
        return Address;
    }
    
}
