/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Front_End;

import java.sql.*;
import javax.swing.JOptionPane;


public class pricing_module {
    
    double Comp_profit = .1;// CONSTANT COMPANY PROFIT
    double CP = 1.5; // Current price
    
    double locf = -1; // (in or out of texas?) location factor
    double history = -1; // rate history (previous client?)
    double gallonsfactor = -1;
    double rf = -1; // rate fluctuation
    
    public pricing_module(String State, String uname, double gallons, String date){ // User must fill out all criteria to calculate prices
    
        if(State == "TX"){ // determines whether in or out of texas
            locf = .02;
        }
        else{
            locf = .04;
        }
        
        
        
        DbConnect H = new DbConnect();
        if(H.checkhistory(uname)){ // determines if they are a previous client
            history = .01;
        }
        else{
            history = 0;
        }
        
        
        
        
        if(gallons>1000){ // sets the gallons factor
            gallonsfactor = .02;
        }
        else{
            gallonsfactor = .03;
        }
        
        int a = Character.getNumericValue(date.charAt(6));
        String b = Character.toString(date.charAt(8))+Character.toString(date.charAt(9));
        int c = Integer.parseInt(b);
        if(a==6 && c>=21){
            rf = .04;
        }
        else if(a==9 && c<=23){
            rf = .04;
        }
        else if(a<9 && a>6){
            rf = .04;
        }
        else{
            rf = .03;
        }
        
        
        
        
    }
    
 
    
    public boolean satisfies(){
        
        if(locf == -1 || history == -1|| gallonsfactor ==-1||rf == -1){
            return false;
        }
        else{
            return true;
        }
    
    }
    
        
}
