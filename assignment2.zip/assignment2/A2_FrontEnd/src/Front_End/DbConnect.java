/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Front_End;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class DbConnect {
    
    private Connection con;
    private Statement st;
    private ResultSet rs;
    
    
    public DbConnect(){
            
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
            
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fuelclients","jshenry","Jonathan1!");
        
            }catch(Exception e){
                System.out.println("Error: "+e);
                JOptionPane.showMessageDialog(null,"Cannot establish connection to server");
            }   
    }
    
    
        
    
    public boolean loginattempt(String usern, String pass){

        int verified =0;
        try{
            if(usern!=null && pass!=null){
                String query = "Select username,password from users where username='"+usern+"' and password='"+pass+"'";
                PreparedStatement st = con.prepareStatement(query);
                rs = st.executeQuery(query);
            
                if(rs.next()){
                    return true;
                }
            
            }
        }
        catch(Exception e){
            
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
            
        }
        return false;
    }
    
    public boolean dataentry(String username,String fullname,String A1,String A2, String City, String Zip, String State, int randomnumber, String pword){
        int check = 0;
        try{
            
            String query = "insert into qforms (qnumber,username,name,address1,address2,city,zip,state)" + " values (?,?,?,?,?,?,?,?)";
            

            PreparedStatement st = con.prepareStatement(query);     
            st.setInt(1,randomnumber);
            st.setString(2,username);
            st.setString(3,fullname);
            st.setString(4, A1);
            st.setString(5, A2);
            st.setString(6, City);
            st.setString(7, Zip);
            st.setString(8, State);
            st.execute();
            
            String query2 = "insert into users (qnumber,username,password)"+ " values (?,?,?)";
            
            st = con.prepareStatement(query2);
            st.setInt(1,randomnumber);
            st.setString(2,username);
            st.setString(3,pword);
            st.execute();
            
            check =1;
            
        }catch(Exception e){

            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
          
        }
        if(check ==1){
            return true;
        }
        else{
            return false;
        }
    
    }
    
    public boolean checkuser(String username){ 
        int count = 0;
        try{
            String query = "select * from users where username='"+username+"'";
            rs = st.executeQuery(query);
            while(rs.next()){
                    count = 1;
            }
        }
        catch(Exception e){
            
        }
        if (count == 0){ // if no duplcates are encounted then true is returned
            return true;
        }
        else{
            return false;
        }
        
    }
    
    public boolean checkhistory(String uname){ 
        int count = 0;
        try{
            String query = "select * from qhistory where username='"+uname+"'";
            rs = st.executeQuery(query);
            while(rs.next()){
                    count = 1;
            }
        }
        catch(Exception e){
            
        }
        if (count == 0){ // if no history is found then false is returned
            return false;
        }
        else{
            return true;
        }
        
    }
    
    public boolean newquoteform( int randomnumber,String usern,double gallamount,double suggestedprice, double totaldue, String deliveryaddress){
        
        int check = 0;
        try{
            
            String query = "insert into qhistory (qnumber,username,gallons,suggestprice,totaldue,deliveryaddress)" + " values (?,?,?,?,?,?)";
            

            PreparedStatement st = con.prepareStatement(query); 
            st.setInt(1,randomnumber);
            st.setString(2,usern);
            st.setDouble(3,gallamount);
            st.setDouble(4,suggestedprice);
            st.setDouble(5, totaldue);
            st.setString((6),deliveryaddress);
            
            st.execute();
            
           
            check =1;
           
            
        }catch(Exception e){

            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
          
        }
        if(check ==1){
            return true;
        }
        else{
            return false;
        }
    
    }
    
    public ArrayList<User> createTable(ArrayList<User> userlist){ //uli = userloggedin
        try{
            String Query1="select * from qhistory";
            st = con.createStatement();
            rs = st.executeQuery(Query1);
            User user;
            while(rs.next()){
                user = new User(rs.getInt("qnumber"),rs.getInt("gallons"),rs.getInt("suggestprice"),rs.getInt("totaldue"),rs.getString("username"),rs.getString("deliveryaddress"));
                userlist.add(user);
            }
        }
        catch(Exception e){
        
        }
        return userlist;
    
    }
    
}
        
    

